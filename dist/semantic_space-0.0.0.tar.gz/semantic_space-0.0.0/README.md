# sematnic-space

A basic NLP library for modelization and tokenization.

_pip install libnlp_

## Project Details

This is a project where I collect the codes that I have written
for NLP applications. I have modularized some of the code that
I have used for [AhmetGPT](https://github.com/ahmeterdem1/ahmetgpt), and prepared
a well-structured library for similar applications. The code may be buggy, haven't
properly tested it yet. But it is there.

## Documentation

Preparation of the documentation is still in progress. However, the docstrings are
there in the code. You can check it out if you want!

